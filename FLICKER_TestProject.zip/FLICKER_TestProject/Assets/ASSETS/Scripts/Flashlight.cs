using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

public class Flashlight : MonoBehaviour
{
    public Light spotlight;
    public float flashlightIntensity = 5.0f;
    public float stunIntensityMultiplier = 2.0f;
    public float stunActiveTime = 3.0f;
    public Color stunColor = Color.blue;

    private bool isActive = false;
    private bool stunActive = false;
    [SerializeField]private GameObject stunTrigger;

    private void Start()
    {
        // flashlight begins off, with stun trigger off aswell.
        spotlight.intensity = 0f;
        stunTrigger.SetActive(false);
    }

    void Update()
    {
        // abstracted controls of flashlight to keep Update function clean
        flashlightControl();
    }

    /** Handles all input functions of the flashlight
     * RMB - turn on and off
     * LMB - while on, uses stun flash
     * 
     */
    void flashlightControl()
    {
        // turn flashlight off
        if (Input.GetMouseButtonDown(1) && isActive)
        {
            spotlight.intensity = 0;
            isActive = false;
        } // turn flashlight on
        else if (Input.GetMouseButtonDown(1) && !isActive)
        {
            spotlight.intensity = flashlightIntensity;
            isActive = true;
        }

        // use stun
        if (Input.GetMouseButtonDown(0) && isActive && !stunActive)
        {
            //Debug.Log("Stun input detected");
            // activate stun trigger
            stunTrigger.SetActive(true);
            // change stun isActive state, begin stun light coroutine.
            stunActive = true;
            StartCoroutine(FadeIntensity(spotlight.intensity, spotlight.intensity * stunIntensityMultiplier, stunActiveTime));
        }
    }



    /** Coroutine that handles the stun ability of the flashlight
     */
    IEnumerator FadeIntensity(float startIntensity, float targetIntensity, float duration)
    {
        // store original color, change color, and begin timer
        float elapsedTime = 0f;
        Color baseColor = spotlight.color;
        spotlight.color = stunColor;

        while (elapsedTime < duration)
        {
            // slowly fade color and intensity back to original flashlight values
            spotlight.intensity = Mathf.Lerp(targetIntensity, startIntensity, elapsedTime / duration);
            spotlight.color = Color.Lerp(stunColor, baseColor, elapsedTime / duration);
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        // Reset values to avoid rounding issues
        spotlight.intensity = startIntensity;
        spotlight.color = baseColor;

        // Reset isActive and stunTrigger
        stunTrigger.SetActive(false);
        stunActive = false;
    }
}