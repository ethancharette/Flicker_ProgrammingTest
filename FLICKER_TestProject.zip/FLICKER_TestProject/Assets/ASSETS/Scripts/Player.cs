using UnityEngine;

public class Player : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 10f;
    public float jumpForce = 10f;
    [Space]
    [Header("Tools")]
    public bool hasWrench;
    public bool hasHammer;
    public bool hasScrewdriver;

    Vector3 move;
    private Rigidbody rb;
    private CapsuleCollider collider;
    private SpriteRenderer sr;

    private void Start()
    {
        // get references to components
        rb = GetComponent<Rigidbody>();
        collider = GetComponent<CapsuleCollider>();
        sr = GetComponent<SpriteRenderer>();

    }

    void Update()
    {
        // movement direction
        move = new Vector3(Input.GetAxis("Horizontal"), 0f, 0f);

        // jump handler
        if (Input.GetKeyDown(KeyCode.Space) && isGrounded())
        {
            // Apply upward force for jumping
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        }
        spriteDirection();
    }

       
    void FixedUpdate()
    {
        // Horizontal movement of player
        rb.MovePosition(rb.position + (move * moveSpeed * Time.deltaTime));
    }

    /** Checks if the player is currently grounded.
     *  Returns boolean.
     */
    bool isGrounded()
    {
        float distanceToGround = collider.bounds.extents.y + 0.5f; // 0.5f is an offest added to make jumping friendlier


        // downward raycast to check for ground
        if (Physics.Raycast(transform.position, Vector3.down, distanceToGround))
        {
            //Debug.Log("Grounded");
            return true;
        }
        //Debug.Log("Not Grounded");
        return false;
    }

    /** Sets the SpriteRenderer flipX boolean based off the x coordinates of the mouse
     */
    void spriteDirection()
    {
        // gets in world mouse position
        Vector3 mousePosition = Input.mousePosition;
        mousePosition.z = transform.position.z - Camera.main.transform.position.z; // offset z pos by camera world position.
        mousePosition = Camera.main.ScreenToWorldPoint(mousePosition);

        //Debug.Log("Mouse Position: " + mousePosition);
        //Debug.Log("Player Position: " + transform.position);

        // flips the sprite based on the x coordinate of the mouse position
        sr.flipX = (mousePosition.x < transform.position.x);
    }

    public void AddTool(string itemName)
    {
        if (!hasWrench && itemName == "Wrench")
        {
            hasWrench = true;
            //Debug.Log("Tool acquired: " + itemName);
        }
        else if (!hasHammer && itemName == "Hammer")
        {
            hasHammer = true;
            //Debug.Log("Tool acquired: " + itemName);
        }
        else if (!hasScrewdriver && itemName == "Screwdriver")
        {
            hasScrewdriver = true;
            //Debug.Log("Tool acquired: " + itemName);
        }
        else
        {
            //Debug.Log("Item picked up: "+itemName);
        }
    }
}