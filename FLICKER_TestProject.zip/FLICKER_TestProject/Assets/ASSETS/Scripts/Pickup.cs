using System;
using UnityEngine;

public class Pickup : MonoBehaviour
{
    public string toolName;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            // pickup item
            other.GetComponent<Player>().AddTool(toolName);
            Destroy(gameObject);
        }
    }
}
