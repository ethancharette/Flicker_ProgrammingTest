namespace Unity.PlasticSCM.Editor.Help
{
    internal class ExternalLink
    {
        internal string Label;
        internal string Url;
    }
}
